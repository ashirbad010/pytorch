.. _governance:

Lightning Governance | Persons of interest
==========================================

BDFL
----
Role: All final decisions related to Lightning.

- William Falcon (`williamFalcon <https://github.com/williamFalcon>`_) (Lightning founder)


Leads
-----
- Jirka Borovec (`Borda <https://github.com/Borda>`_)
- Ethan Harris (`ethanwharris <https://github.com/ethanwharris>`_) (Torchbearer founder)
- Justus Schock (`justusschock <https://github.com/justusschock>`_) (Former Core Member PyTorch Ignite)
- Adrian Wälchli (`awaelchli <https://github.com/awaelchli>`_)
- Thomas Chaton (`tchaton <https://github.com/tchaton>`_)
- Sean Narenthiran (`SeanNaren <https://github.com/SeanNaren>`_)
- Carlos Mocholí (`carmocca <https://github.com/carmocca>`_)
- Kaushik Bokka (`kaushikb11 <https://github.com/kaushikb11>`_)

Core Maintainers
----------------
- Nicki Skafte (`skaftenicki <https://github.com/SkafteNicki>`_)
- Rohit Gupta (`rohitgr7 <https://github.com/rohitgr7>`_)
- Jeff Yang (`ydcjeff <https://github.com/ydcjeff>`_)
- Roger Shieh (`s-rog <https://github.com/s-rog>`_)
- Ananth Subramaniam (`ananthsub <https://github.com/ananthsub>`_)
- Akihiro Nitta (`akihironitta <https://github.com/akihironitta>`_)

Board
-----
- Jeremy Jordan (`jeremyjordan <https://github.com/jeremyjordan>`_)
- Tullie Murrell (`tullie <https://github.com/tullie>`_)
- Nic Eggert (`neggert <https://github.com/neggert>`_)
- Matthew Painter (`MattPainter01 <https://github.com/MattPainter01>`_) (Torchbearer founder)


Alumni
------
- Jeff Ling (`jeffling <https://github.com/jeffling>`_)
- Teddy Koker (`teddykoker <https://github.com/teddykoker>`_)
- Nate Raw (`nateraw <https://github.com/nateraw>`_)
- Peter Yu (`yukw777 <https://github.com/yukw777>`_)
