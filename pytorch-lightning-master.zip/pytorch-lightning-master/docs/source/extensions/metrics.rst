#######
Metrics
#######

``pytorch_lightning.metrics`` has been moved to a separate package `TorchMetrics <https://torchmetrics.readthedocs.io/>`_.
We will preserve compatibility for the next few releases, nevertheless, we encourage users to update to use this stand-alone package.

.. warning::
    ``pytorch_lightning.metrics`` is deprecated from v1.3 and will be removed in v1.5.
