.. role:: hidden
    :class: hidden-section

.. _profiler:

Performance and Bottleneck Profiler
===================================
.. automodule:: pytorch_lightning.profiler
   :noindex:
   :exclude-members:
        _abc_impl,
        summarize,
