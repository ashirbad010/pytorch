---
name: Typos and doc fixes
about: Typos and doc fixes
title: ''
labels: typo, documentation
assignees: ''

---

## 📚 Documentation

For typos and doc fixes, please go ahead and:

1. Create an issue.
2. Fix the typo.
3. Submit a PR.

Thanks!
